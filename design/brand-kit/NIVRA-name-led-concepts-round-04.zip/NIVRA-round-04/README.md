# NIVRA round 04

Three name-led identity concepts. Awaiting Harsh's selection; all previous rounds rejected.

1. Name as mark: uppercase NIVRA, obsidian/yellow.
2. Engineered humanity: title-case Nivra with signature N, wine/garnet.
3. Connected lettering: lowercase nivra, ink/frost/cyan.

Each folder contains a full-color visual kit board and exact color tokens. See REVIEW.md for inspection and remaining refinements. These are exploratory raster boards, not a finished production asset kit.

Competitor research remains at ../round-03/COMPETITOR-RESEARCH.md; its strategic recommendations are historical and the round-04 brief supersedes its concept direction.
