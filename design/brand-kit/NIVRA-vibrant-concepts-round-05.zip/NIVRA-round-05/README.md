# NIVRA: saturated visual kit concepts

Status: three alternatives for Harsh's selection. No route has been approved. Earlier rounds were rejected.

1. Electric: electric violet + acid lime, custom lowercase wordmark and NV symbol.
2. Signal: scarlet + ultramarine, custom uppercase wordmark and extracted N.
3. Vivid: teal + tangerine + deep purple, title-case wordmark and matching sculpted N.

Each folder contains a full visual brand board, written concept guidelines, JSON color tokens and CSS color variables. The boards show palette, typography direction, one-color use, app presence, staff materials, public-space signage and a cover. These are concept kits, not finished vector/export packages.

See REVIEW.md for limitations and individual tokens.json files for measured intended-color contrast. Generated pixel colors and font appearance are approximate. Fonts, exact vector construction and production templates will be finalized after selection.

Competitor evidence from official sites was gathered earlier in this same project: ../round-03/COMPETITOR-RESEARCH.md. Those visual observations remain relevant; its older concept recommendations have been superseded by the current brief and feedback.
